import React, { useState } from 'react';
import { MapContainer, TileLayer, Marker, Popup } from 'react-leaflet';
import { format } from 'date-fns';
import 'leaflet/dist/leaflet.css';

interface FireStation {
  name: string;
  latitude: number;
  longitude: number;
  phone: string;
}

interface DetectionResult {
  status: string;
  confidence: number;
  nearest_station?: string;
  distance_km?: number;
  notification_sent?: boolean;
  timestamp: string;
}

const fireStations: FireStation[] = [
  { name: "Station 1", latitude: 34.0522, longitude: -118.2437, phone: "+1234567890" },
  { name: "Station 2", latitude: 34.0548, longitude: -118.2850, phone: "+1234567891" },
  { name: "Station 3", latitude: 34.0624, longitude: -118.2987, phone: "+1234567892" }
];

function App() {
  const [selectedImage, setSelectedImage] = useState<File | null>(null);
  const [detectionResult, setDetectionResult] = useState<DetectionResult | null>(null);
  const [loading, setLoading] = useState(false);

  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setSelectedImage(file);
    }
  };

  const processImage = async () => {
    setLoading(true);
    // Simulate API call to backend
    setTimeout(() => {
      const mockResult: DetectionResult = {
        status: Math.random() > 0.5 ? "Fire detected" : "No fire detected",
        confidence: Math.random(),
        nearest_station: "Station 1",
        distance_km: 2.5,
        notification_sent: true,
        timestamp: new Date().toISOString()
      };
      setDetectionResult(mockResult);
      setLoading(false);
    }, 2000);
  };

  return (
    <div className="min-h-screen bg-gray-100">
      <header className="bg-red-600 text-white shadow">
        <div className="max-w-7xl mx-auto py-6 px-4">
          <h1 className="text-3xl font-bold">Wildfire Detection System</h1>
        </div>
      </header>

      <main className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Left Column - Upload and Results */}
          <div className="bg-white shadow rounded-lg p-6">
            <div className="mb-6">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Upload Satellite Image
              </label>
              <input
                type="file"
                accept="image/*"
                onChange={handleImageUpload}
                className="block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-red-50 file:text-red-700 hover:file:bg-red-100"
              />
            </div>

            <button
              onClick={processImage}
              disabled={!selectedImage || loading}
              className="w-full bg-red-600 text-white py-2 px-4 rounded-md hover:bg-red-700 disabled:bg-gray-400"
            >
              {loading ? 'Processing...' : 'Analyze Image'}
            </button>

            {detectionResult && (
              <div className="mt-6 p-4 border rounded-lg">
                <h3 className="text-lg font-semibold mb-2">Detection Results</h3>
                <div className="space-y-2">
                  <p>Status: <span className={detectionResult.status.includes('Fire') ? 'text-red-600 font-bold' : 'text-green-600'}>{detectionResult.status}</span></p>
                  <p>Confidence: {(detectionResult.confidence * 100).toFixed(2)}%</p>
                  {detectionResult.nearest_station && (
                    <>
                      <p>Nearest Station: {detectionResult.nearest_station}</p>
                      <p>Distance: {detectionResult.distance_km?.toFixed(2)} km</p>
                    </>
                  )}
                  <p>Time: {format(new Date(detectionResult.timestamp), 'PPpp')}</p>
                </div>
              </div>
            )}
          </div>

          {/* Right Column - Map */}
          <div className="bg-white shadow rounded-lg p-6">
            <MapContainer
              center={[34.0522, -118.2437]}
              zoom={12}
              style={{ height: '500px', width: '100%' }}
            >
              <TileLayer
                url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
              />
              {fireStations.map((station) => (
                <Marker
                  key={station.name}
                  position={[station.latitude, station.longitude]}
                >
                  <Popup>
                    <div>
                      <h3 className="font-bold">{station.name}</h3>
                      <p>Phone: {station.phone}</p>
                    </div>
                  </Popup>
                </Marker>
              ))}
            </MapContainer>
          </div>
        </div>
      </main>
    </div>
  );
}

export default App;