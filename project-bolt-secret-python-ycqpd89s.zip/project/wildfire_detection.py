import os
import math
import json
from datetime import datetime
import random  # For demonstration purposes only

class SatelliteImage:
    def __init__(self, path, latitude, longitude):
        self.path = path
        self.latitude = latitude
        self.longitude = longitude
        
    def load(self):
        """
        Simulate loading a satellite image.
        In a real system, this would use libraries like PIL or OpenCV.
        """
        return f"Loaded image from {self.path}"

class FireStation:
    def __init__(self, name, latitude, longitude, phone):
        self.name = name
        self.latitude = latitude
        self.longitude = longitude
        self.phone = phone

class WildfireDetectionSystem:
    def __init__(self):
        # Initialize with some sample fire stations
        self.fire_stations = [
            FireStation("Station 1", 34.0522, -118.2437, "+1234567890"),
            FireStation("Station 2", 34.0548, -118.2850, "+1234567891"),
            FireStation("Station 3", 34.0624, -118.2987, "+1234567892")
        ]
        
    def preprocess_image(self, image):
        """
        Simulate image preprocessing.
        In a real system, this would normalize and resize the image.
        """
        print(f"Preprocessing image: {image}")
        return image
    
    def detect_fire(self, processed_image):
        """
        Simulate fire detection.
        In a real system, this would use a trained deep learning model.
        """
        # For demonstration, randomly detect fire with 30% probability
        is_fire = random.random() < 0.3
        confidence = random.uniform(0.7, 0.99) if is_fire else random.uniform(0.1, 0.3)
        
        return {
            "fire_detected": is_fire,
            "confidence": confidence,
            "timestamp": datetime.now().isoformat()
        }
    
    def calculate_distance(self, lat1, lon1, lat2, lon2):
        """
        Calculate distance between two points using Haversine formula
        """
        R = 6371  # Earth's radius in kilometers
        
        lat1_rad = math.radians(lat1)
        lat2_rad = math.radians(lat2)
        delta_lat = math.radians(lat2 - lat1)
        delta_lon = math.radians(lon2 - lon1)
        
        a = math.sin(delta_lat/2) * math.sin(delta_lat/2) + \
            math.cos(lat1_rad) * math.cos(lat2_rad) * \
            math.sin(delta_lon/2) * math.sin(delta_lon/2)
        
        c = 2 * math.atan2(math.sqrt(a), math.sqrt(1-a))
        distance = R * c
        
        return distance
    
    def find_nearest_station(self, latitude, longitude):
        """
        Find the nearest fire station to the detected fire
        """
        nearest_station = None
        min_distance = float('inf')
        
        for station in self.fire_stations:
            distance = self.calculate_distance(
                latitude, longitude,
                station.latitude, station.longitude
            )
            
            if distance < min_distance:
                min_distance = distance
                nearest_station = station
        
        return nearest_station, min_distance
    
    def send_notification(self, station, fire_location, confidence):
        """
        Simulate sending notification to fire station.
        In a real system, this would use an SMS or email service.
        """
        message = {
            "to": station.name,
            "phone": station.phone,
            "message": f"ALERT: Wildfire detected!\n" \
                      f"Location: {fire_location['latitude']}, {fire_location['longitude']}\n" \
                      f"Confidence: {confidence:.2%}\n" \
                      f"Time: {datetime.now().isoformat()}"
        }
        
        print("\nSending notification:")
        print(json.dumps(message, indent=2))
        return message
    
    def process_satellite_image(self, image_path, latitude, longitude):
        """
        Main method to process a satellite image and handle fire detection
        """
        # Create and load satellite image
        satellite_image = SatelliteImage(image_path, latitude, longitude)
        image_data = satellite_image.load()
        
        # Preprocess image
        processed_image = self.preprocess_image(image_data)
        
        # Detect fire
        detection_result = self.detect_fire(processed_image)
        
        if detection_result["fire_detected"]:
            # Find nearest fire station
            nearest_station, distance = self.find_nearest_station(latitude, longitude)
            
            # Send notification
            notification = self.send_notification(
                nearest_station,
                {"latitude": latitude, "longitude": longitude},
                detection_result["confidence"]
            )
            
            return {
                "status": "Fire detected",
                "confidence": detection_result["confidence"],
                "nearest_station": nearest_station.name,
                "distance_km": distance,
                "notification_sent": True,
                "timestamp": detection_result["timestamp"]
            }
        
        return {
            "status": "No fire detected",
            "confidence": detection_result["confidence"],
            "timestamp": detection_result["timestamp"]
        }