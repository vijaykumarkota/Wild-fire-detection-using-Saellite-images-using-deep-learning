from wildfire_detection import WildfireDetectionSystem

def main():
    # Initialize the wildfire detection system
    system = WildfireDetectionSystem()
    
    # Test with sample satellite image data
    print("Testing Wildfire Detection System...")
    print("-" * 50)
    
    # Test multiple locations to demonstrate the system
    test_locations = [
        ("satellite_image_1.jpg", 34.0522, -118.2437),  # Los Angeles
        ("satellite_image_2.jpg", 34.0548, -118.2850),  # Another LA location
    ]
    
    for image_path, lat, lon in test_locations:
        print(f"\nProcessing image: {image_path}")
        print(f"Location: {lat}, {lon}")
        
        result = system.process_satellite_image(image_path, lat, lon)
        
        print("\nResult:")
        for key, value in result.items():
            print(f"{key}: {value}")
        print("-" * 50)

if __name__ == "__main__":
    main()